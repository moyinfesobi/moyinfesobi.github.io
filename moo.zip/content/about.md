Personality testing and assessment refer to techniques that are used to accurately and consistently measure personality.

Personality tests can be used to help furthur clarify a clinical diagnosis, to guide therapeutic interventions, and to help predict how people may respond in different situations.


Personality is something that we informally assess and describe every day. When we talk about ourselves and others, we frequently refer to different characteristics of an individual's personality.

Psychologists do much the same thing when they assess personality but on a much more systematic and scientific level.